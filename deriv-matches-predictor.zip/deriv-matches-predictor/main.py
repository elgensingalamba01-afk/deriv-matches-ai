"""
Deriv Digit Analyzer — CLI entry point.

    python main.py demo --symbol R_100 --count 5000 --charts
    python main.py analyze --symbol R_100 --count 5000 --charts

`demo` needs nothing but Python — it runs the whole pipeline against
simulated random digits so you can see exactly what "no edge" looks like.
`analyze` connects to the real Deriv API and needs internet access.
"""
from __future__ import annotations
import argparse
import asyncio
import json
import os

import numpy as np

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from src.digit_utils import digits_from_prices
from src.predictor import full_report


def _emit_report(digits, symbol, use_ml, charts):
    report = full_report(digits, symbol, use_ml=use_ml)

    print(f"\n=== Digit report: {symbol} (n={report['sample_size']}) ===\n")

    print("Digit frequency (expect ~10% each if the source is uniform random):")
    for d in range(10):
        print(f"  {d}: {report['digit_frequency_pct'][d]:.2f}%")

    chi = report["chi_square"]
    verdict = "consistent with uniform randomness" if chi["uniform_at_5pct"] else "NOT uniform at 5% significance"
    print(f"\nChi-square uniformity test: chi2={chi['statistic']:.2f}, p={chi['p_value']:.3f} -> {verdict}")

    runs = report["runs_test_per_digit"]
    flagged = sum(1 for d in runs if runs[d]["significant"])
    print(f"Runs test across all 10 digits: {flagged}/10 flagged as non-random at 5% "
          f"significance (~0-1 expected by chance from testing 10 digits).")

    print("\nBacktested strategy accuracy — Matches (baseline 10%) / Differs (baseline 90%):")
    for m, d in zip(report["backtests_matches"], report["backtests_differs"]):
        flag_m = "possible edge" if m.significant else "no edge"
        flag_d = "possible edge" if d.significant else "no edge"
        print(f"  {m.strategy_name:16s} Matches: {m.accuracy*100:5.2f}% (p={m.p_value:.3f}, {flag_m})   "
              f"Differs: {d.accuracy*100:5.2f}% (p={d.p_value:.3f}, {flag_d})")

    print("\nSuggested next digit per strategy (shown with its real backtested accuracy — not a guarantee):")
    for rec in report["live_recommendations"]:
        print(f"  {rec['strategy']:16s} -> digit {rec['suggested_digit']}  "
              f"(this strategy matched exactly {rec['backtested_accuracy']*100:.2f}% of the time historically)")

    print("\nNote: a strategy flagged 'possible edge' only means it cleared a 5%")
    print("significance bar on THIS sample. Testing several strategies across")
    print("several digits means a few will clear that bar by chance alone —")
    print("treat it as something to re-test on fresh data, not as proof.")

    os.makedirs("output", exist_ok=True)
    serializable = {
        "symbol": report["symbol"],
        "sample_size": report["sample_size"],
        "digit_frequency_pct": report["digit_frequency_pct"],
        "chi_square": report["chi_square"],
        "autocorrelation_lag1_10": report["autocorrelation_lag1_10"],
        "runs_test_per_digit": report["runs_test_per_digit"],
        "transition_matrix": report["transition_matrix"],
        "backtests_matches": [r.__dict__ for r in report["backtests_matches"]],
        "backtests_differs": [r.__dict__ for r in report["backtests_differs"]],
        "live_recommendations": report["live_recommendations"],
    }
    out_path = f"output/{symbol}_report.json"
    with open(out_path, "w") as f:
        json.dump(serializable, f, indent=2)
    print(f"\nSaved full report: {out_path}")

    if charts:
        try:
            from src import visualizer
        except ImportError:
            print("matplotlib isn't installed — skipping charts (pip install matplotlib).")
        else:
            visualizer.plot_digit_frequency(report["digit_frequency_pct"], symbol, f"output/{symbol}_digit_frequency.png")
            visualizer.plot_transition_heatmap(np.array(report["transition_matrix"]), symbol, f"output/{symbol}_transitions.png")
            visualizer.plot_backtest_accuracy(report["backtests_matches"], f"output/{symbol}_backtest_accuracy.png")
            print(f"Saved charts to output/{symbol}_*.png")


def run_demo(symbol: str, count: int, seed: int, use_ml: bool, charts: bool):
    print(f"[DEMO MODE] Simulating {count} i.i.d. uniform random ticks for {symbol}.")
    print("No connection to Deriv is made — this exercises the exact same")
    print("statistics/backtesting code against data we KNOW is random, so you")
    print("can see what 'no edge' looks like before pointing it at real data.")
    rng = np.random.default_rng(seed)
    digits = rng.integers(0, 10, size=count).tolist()
    _emit_report(digits, symbol, use_ml, charts)


async def run_live(symbol: str, count: int, app_id: str, use_ml: bool, charts: bool):
    from src.api_client import DerivClient
    print(f"Connecting to Deriv API (app_id={app_id}) for {symbol}...")
    async with DerivClient(app_id=app_id) as client:
        pip_size = await client.get_pip_size(symbol)
        prices, _times = await client.get_tick_history(symbol, count=count)
    digits = digits_from_prices(prices, pip_size=pip_size)
    _emit_report(digits, symbol, use_ml, charts)


def main():
    parser = argparse.ArgumentParser(description="Deriv digit statistics & backtesting analyzer")
    sub = parser.add_subparsers(dest="command", required=True)

    demo_p = sub.add_parser("demo", help="Run against simulated random data — no internet or API key needed")
    demo_p.add_argument("--symbol", default="R_100")
    demo_p.add_argument("--count", type=int, default=5000)
    demo_p.add_argument("--seed", type=int, default=42)
    demo_p.add_argument("--no-ml", action="store_true")
    demo_p.add_argument("--charts", action="store_true")

    live_p = sub.add_parser("analyze", help="Pull real tick history from Deriv and analyze it")
    live_p.add_argument("--symbol", default="R_100")
    live_p.add_argument("--count", type=int, default=5000)
    live_p.add_argument("--app-id", default=os.environ.get("DERIV_APP_ID", "1089"))
    live_p.add_argument("--no-ml", action="store_true")
    live_p.add_argument("--charts", action="store_true")

    args = parser.parse_args()
    if args.command == "demo":
        run_demo(args.symbol, args.count, args.seed, not args.no_ml, args.charts)
    else:
        asyncio.run(run_live(args.symbol, args.count, args.app_id, not args.no_ml, args.charts))


if __name__ == "__main__":
    main()
