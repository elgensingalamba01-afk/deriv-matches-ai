"""
Sanity tests using simulated i.i.d. uniform digits (NumPy's RNG). If
Deriv's synthetic indices are implemented as advertised, running this same
suite against real tick data should look similar: uniform frequency, no
significant runs-test signal, and every strategy's backtested accuracy
sitting close to its baseline.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src import statistics_analysis as stats_mod
from src.backtester import backtest_exact_match
from src.strategies import ColdNumberStrategy, FrequencyStrategy, MarkovStrategy


def _simulated_digits(n=8000, seed=1):
    rng = np.random.default_rng(seed)
    return rng.integers(0, 10, size=n).tolist()


def test_frequency_is_roughly_uniform():
    digits = _simulated_digits()
    freq = stats_mod.digit_frequency(digits)
    for d in range(10):
        assert 7.0 < freq[d] < 13.0, f"digit {d} frequency {freq[d]:.2f}% looks off for uniform data"


def test_chi_square_does_not_reject_uniformity():
    digits = _simulated_digits()
    _, p = stats_mod.chi_square_uniformity(digits)
    assert p > 0.01, f"chi-square rejected uniformity on known-uniform data (p={p:.4f})"


def test_strategies_do_not_beat_baseline_on_random_data():
    digits = _simulated_digits()
    for strategy_cls in (FrequencyStrategy, ColdNumberStrategy, MarkovStrategy):
        result = backtest_exact_match(strategy_cls(), digits)
        assert 0.06 < result.accuracy < 0.14, (
            f"{strategy_cls.__name__} scored {result.accuracy*100:.2f}% on data known "
            "to be random — that would flag a bug in the code, not a real edge."
        )


if __name__ == "__main__":
    test_frequency_is_roughly_uniform()
    test_chi_square_does_not_reject_uniformity()
    test_strategies_do_not_beat_baseline_on_random_data()
    print("All sanity tests passed: the framework correctly reports no edge on known-random data.")
