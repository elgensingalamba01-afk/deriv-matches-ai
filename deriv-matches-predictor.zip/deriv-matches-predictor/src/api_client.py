"""
Minimal async client for the public Deriv WebSocket API — just enough to
pull tick history and (optionally) stream live ticks. No account login or
API token is required for any of this; a free `app_id` is enough, or you
can use Deriv's public test app_id (1089) to try things out immediately.

Docs: https://developers.deriv.com
"""
from __future__ import annotations
import json
from typing import Callable, List, Tuple

import websockets

DERIV_WS_URL = "wss://ws.derivws.com/websockets/v3?app_id={app_id}"


class DerivClient:
    def __init__(self, app_id: str = "1089"):
        self.app_id = app_id
        self.url = DERIV_WS_URL.format(app_id=app_id)
        self.ws = None

    async def connect(self):
        self.ws = await websockets.connect(self.url, ping_interval=20)

    async def close(self):
        if self.ws is not None:
            await self.ws.close()

    async def _request(self, payload: dict) -> dict:
        await self.ws.send(json.dumps(payload))
        response = json.loads(await self.ws.recv())
        if "error" in response:
            raise RuntimeError(f"Deriv API error: {response['error'].get('message', response['error'])}")
        return response

    async def get_pip_size(self, symbol: str) -> float:
        """Look up the pip size (e.g. 0.01) for `symbol` via active_symbols,
        so digit extraction always uses the correct decimal precision
        instead of a hardcoded guess."""
        response = await self._request({"active_symbols": "brief"})
        for sym in response.get("active_symbols", []):
            if sym.get("symbol") == symbol:
                return float(sym.get("pip", 0.01))
        return 0.01

    async def get_tick_history(self, symbol: str, count: int = 5000) -> Tuple[List[float], List[int]]:
        response = await self._request({
            "ticks_history": symbol,
            "adjust_start_time": 1,
            "count": count,
            "end": "latest",
            "start": 1,
            "style": "ticks",
        })
        history = response["history"]
        return history["prices"], history["times"]

    async def stream_ticks(self, symbol: str, on_tick: Callable[[dict], None]):
        """Subscribes to live ticks and calls `on_tick(tick_dict)` for each
        one as it arrives. Runs until cancelled by the caller."""
        await self.ws.send(json.dumps({"ticks": symbol, "subscribe": 1}))
        while True:
            message = json.loads(await self.ws.recv())
            if message.get("msg_type") == "tick" and "tick" in message:
                on_tick(message["tick"])

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.close()
