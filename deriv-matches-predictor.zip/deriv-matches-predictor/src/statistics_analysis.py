"""
Statistical tests for checking whether a digit sequence behaves like i.i.d.
uniform random draws (as expected from a well-built RNG) or shows
structure that a naive "pattern" story might latch onto.
"""
from __future__ import annotations
from collections import Counter
from typing import Dict, List, Tuple

import numpy as np
from scipy import stats


def digit_frequency(digits: List[int]) -> Dict[int, float]:
    """Percentage frequency of each digit 0-9. Should hover near 10% each
    if the source is uniform random."""
    n = len(digits)
    if n == 0:
        return {d: 0.0 for d in range(10)}
    counts = Counter(digits)
    return {d: counts.get(d, 0) / n * 100 for d in range(10)}


def chi_square_uniformity(digits: List[int]) -> Tuple[float, float]:
    """Chi-square goodness-of-fit test against a uniform distribution over
    0-9. Returns (chi2_statistic, p_value); a low p-value (<0.05) would be
    evidence the digits are NOT uniformly distributed."""
    n = len(digits)
    if n == 0:
        return 0.0, 1.0
    counts = Counter(digits)
    observed = np.array([counts.get(d, 0) for d in range(10)])
    expected = np.full(10, n / 10)
    chi2, p = stats.chisquare(observed, expected)
    return float(chi2), float(p)


def runs_test(binary_sequence: List[int]) -> Tuple[float, float]:
    """Wald-Wolfowitz runs test for randomness of a 0/1 sequence. Returns
    (z_statistic, p_value); a low p-value suggests the sequence isn't
    randomly ordered (too streaky, or alternating too much to be chance)."""
    seq = np.array(binary_sequence)
    n = len(seq)
    if n < 2:
        return 0.0, 1.0
    n1 = int(np.sum(seq == 1))
    n0 = n - n1
    if n1 == 0 or n0 == 0:
        return 0.0, 1.0
    runs = 1 + int(np.sum(seq[1:] != seq[:-1]))
    runs_exp = (2 * n1 * n0) / n + 1
    denom = (n ** 2) * (n - 1)
    if denom == 0:
        return 0.0, 1.0
    runs_var = (2 * n1 * n0 * (2 * n1 * n0 - n)) / denom
    if runs_var <= 0:
        return 0.0, 1.0
    z = (runs - runs_exp) / np.sqrt(runs_var)
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    return float(z), float(p)


def autocorrelation(digits: List[int], max_lag: int = 10) -> List[float]:
    """Autocorrelation of the digit sequence at lags 1..max_lag. Values
    near zero at every lag indicate no linear serial dependence."""
    n = len(digits)
    if n <= max_lag:
        return [0.0] * max_lag
    x = np.array(digits, dtype=float)
    x = x - x.mean()
    denom = np.sum(x ** 2)
    result = []
    for lag in range(1, max_lag + 1):
        num = np.sum(x[:-lag] * x[lag:])
        result.append(float(num / denom) if denom else 0.0)
    return result


def transition_matrix(digits: List[int]) -> np.ndarray:
    """10x10 matrix M where M[i, j] = P(next digit == j | current digit == i).
    A well-mixed RNG should produce rows that all look roughly uniform."""
    matrix = np.zeros((10, 10))
    for cur, nxt in zip(digits[:-1], digits[1:]):
        matrix[cur, nxt] += 1
    row_sums = matrix.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1
    return matrix / row_sums
