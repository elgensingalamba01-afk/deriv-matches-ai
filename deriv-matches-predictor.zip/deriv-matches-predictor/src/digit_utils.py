"""
Utilities for turning raw Deriv tick quotes into the digit sequence that
Matches/Differs, Even/Odd, and Over/Under contracts are settled on.
"""
from __future__ import annotations
import math
from typing import Iterable, List, Optional, Sequence

# Best-effort fallback if you don't have a pip size handy (e.g. hand-built
# test data). Deriv's `active_symbols` call returns the authoritative pip
# per symbol at runtime (see api_client.DerivClient.get_pip_size), so this
# table is only a backup for offline/demo use — verify against the live
# platform for your chosen symbol before trusting it for real trading.
FALLBACK_DECIMALS = {
    "R_10": 3, "R_25": 3, "R_50": 4, "R_75": 4, "R_100": 2,
    "1HZ10V": 2, "1HZ25V": 2, "1HZ50V": 2, "1HZ75V": 2, "1HZ100V": 2,
}


def decimals_from_pip_size(pip_size: float) -> int:
    """Convert a pip value (e.g. 0.01) into a decimal-place count (e.g. 2)."""
    if pip_size is None or pip_size <= 0:
        return 2
    return max(0, round(-math.log10(pip_size)))


def last_digit(price: float, symbol: str = "", pip_size: Optional[float] = None) -> int:
    """Return the last digit of `price` at the correct decimal precision.

    Pass `pip_size` whenever you have it (every live tick from Deriv
    includes one, and DerivClient.get_pip_size fetches it for history
    pulls) — it's authoritative. `symbol` + the fallback table above is
    only used when no pip size is available at all.
    """
    decimals = decimals_from_pip_size(pip_size) if pip_size is not None else FALLBACK_DECIMALS.get(symbol, 2)
    scaled = round(price * (10 ** decimals))
    return int(scaled % 10)


def digits_from_prices(prices: Sequence[float], symbol: str = "", pip_size: Optional[float] = None) -> List[int]:
    """Convert a list of raw prices (e.g. from ticks_history) into digits."""
    return [last_digit(p, symbol=symbol, pip_size=pip_size) for p in prices]


def digits_from_ticks(ticks: Iterable[dict]) -> List[int]:
    """Convenience for live-streamed tick dicts, each of which includes its
    own `pip_size` and `quote` fields — the most reliable path."""
    return [last_digit(t["quote"], pip_size=t.get("pip_size")) for t in ticks]
