"""
Candidate strategies for predicting the next digit in a Deriv synthetic
index tick stream. Each exposes the same tiny interface so the backtester
can evaluate them identically:

    strategy.predict() -> int      # guess for the NEXT digit, using only
                                     # digits seen so far
    strategy.update(actual_digit)  # tell the strategy what really
                                     # happened, so it can learn/adapt

None of these are claimed to work. They exist so the backtester has
something concrete to measure — the point of this project is finding out
whether any of them beat random guessing, not assuming they do.
"""
from __future__ import annotations
from collections import Counter, deque
from typing import Deque, Optional

import numpy as np


class BaseStrategy:
    name = "base"

    def predict(self) -> int:
        raise NotImplementedError

    def update(self, digit: int) -> None:
        pass


class FrequencyStrategy(BaseStrategy):
    """'Hot number': predicts whichever digit appeared most often in the
    last `window` ticks. This is the strategy most "digit trading" guides
    recommend — the backtester exists to check whether it actually works."""
    name = "frequency"

    def __init__(self, window: int = 50):
        self.buffer: Deque[int] = deque(maxlen=window)

    def predict(self) -> int:
        if not self.buffer:
            return int(np.random.randint(0, 10))
        return Counter(self.buffer).most_common(1)[0][0]

    def update(self, digit: int) -> None:
        self.buffer.append(digit)


class ColdNumberStrategy(BaseStrategy):
    """Gambler's-fallacy baseline: predicts whichever digit has appeared
    LEAST often recently, on the (false, for i.i.d. data) idea that it's
    'due'. Included so the backtester can show this doesn't work either."""
    name = "cold_number"

    def __init__(self, window: int = 50):
        self.buffer: Deque[int] = deque(maxlen=window)

    def predict(self) -> int:
        counts = Counter(self.buffer)
        full = {d: counts.get(d, 0) for d in range(10)}
        return min(full, key=full.get)

    def update(self, digit: int) -> None:
        self.buffer.append(digit)


class MarkovStrategy(BaseStrategy):
    """Predicts the digit most often seen after the current digit,
    learning a first-order transition matrix online as ticks arrive."""
    name = "markov"

    def __init__(self):
        self.matrix = np.zeros((10, 10))
        self.last: Optional[int] = None

    def predict(self) -> int:
        if self.last is None:
            return int(np.random.randint(0, 10))
        row = self.matrix[self.last]
        if row.sum() == 0:
            return int(np.random.randint(0, 10))
        return int(np.argmax(row))

    def update(self, digit: int) -> None:
        if self.last is not None:
            self.matrix[self.last, digit] += 1
        self.last = digit


class MLStrategy(BaseStrategy):
    """Trains a small RandomForest on lagged digits to predict the next
    one, periodically retraining as new data arrives. Included to check
    whether a trained model extracts signal from a well-designed RNG —
    not because one would be expected to. Degrades to random guessing if
    scikit-learn isn't installed, so the rest of the tool still runs."""
    name = "machine_learning"

    def __init__(self, lags: int = 5, retrain_every: int = 250, max_train: int = 2000):
        self.lags = lags
        self.retrain_every = retrain_every
        self.buffer: Deque[int] = deque(maxlen=max_train)
        self.model = None
        self._since_fit = 0

    def _features_targets(self):
        buf = list(self.buffer)
        X, y = [], []
        for i in range(self.lags, len(buf)):
            X.append(buf[i - self.lags:i])
            y.append(buf[i])
        return np.array(X), np.array(y)

    def predict(self) -> int:
        if len(self.buffer) < self.lags + 30:
            return int(np.random.randint(0, 10))
        if self.model is None or self._since_fit >= self.retrain_every:
            try:
                from sklearn.ensemble import RandomForestClassifier
                X, y = self._features_targets()
                self.model = RandomForestClassifier(n_estimators=60, max_depth=6, random_state=0)
                self.model.fit(X, y)
                self._since_fit = 0
            except ImportError:
                if self.model is None:
                    return int(np.random.randint(0, 10))
        self._since_fit += 1
        recent = np.array(list(self.buffer)[-self.lags:]).reshape(1, -1)
        return int(self.model.predict(recent)[0])

    def update(self, digit: int) -> None:
        self.buffer.append(digit)
