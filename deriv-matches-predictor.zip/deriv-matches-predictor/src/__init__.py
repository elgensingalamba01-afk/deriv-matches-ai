"""Deriv digit statistics & backtesting toolkit."""
__version__ = "0.1.0"
