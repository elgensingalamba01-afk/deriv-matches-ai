"""Chart generation for digit statistics reports. Matplotlib only — no
browser/JS dependency, so charts render the same in any environment."""
from __future__ import annotations
from typing import Dict, List

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def plot_digit_frequency(freq: Dict[int, float], symbol: str, out_path: str) -> None:
    digits = list(range(10))
    values = [freq.get(d, 0) for d in digits]
    plt.figure(figsize=(8, 4.5))
    plt.bar(digits, values, color="#4C72B0")
    plt.axhline(10, color="red", linestyle="--", linewidth=1, label="Expected if uniform (10%)")
    plt.xlabel("Last digit")
    plt.ylabel("Frequency (%)")
    plt.title(f"Digit frequency — {symbol}")
    plt.xticks(digits)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()


def plot_transition_heatmap(matrix: np.ndarray, symbol: str, out_path: str) -> None:
    plt.figure(figsize=(6, 5))
    vmax = matrix.max() if matrix.max() > 0 else 1
    plt.imshow(matrix, cmap="viridis", vmin=0, vmax=vmax)
    plt.colorbar(label="P(next digit | current digit)")
    plt.xlabel("Next digit")
    plt.ylabel("Current digit")
    plt.xticks(range(10))
    plt.yticks(range(10))
    plt.title(f"Digit transition matrix — {symbol}")
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()


def plot_backtest_accuracy(results: List, out_path: str) -> None:
    names = [r.strategy_name for r in results]
    accs = [r.accuracy * 100 for r in results]
    baseline = results[0].baseline * 100 if results else 10.0
    plt.figure(figsize=(8, 4.5))
    plt.bar(names, accs, color="#55A868")
    plt.axhline(baseline, color="red", linestyle="--", linewidth=1, label=f"Random-guess baseline ({baseline:.0f}%)")
    plt.ylabel("Prediction accuracy (%)")
    plt.title("Backtested strategy accuracy vs. baseline")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()
