"""
Ties statistics, strategies, and backtesting together into one report.

Deliberately not a black box: every "prediction" this returns is shown
next to the actual backtested accuracy of the strategy that produced it,
so you can judge for yourself whether to trust it rather than take a
number on faith.
"""
from __future__ import annotations
from typing import Dict, List

from . import statistics_analysis as stats_mod
from .backtester import backtest_differs, backtest_exact_match
from .strategies import BaseStrategy, ColdNumberStrategy, FrequencyStrategy, MarkovStrategy, MLStrategy


def build_strategies(use_ml: bool = True) -> List[BaseStrategy]:
    strategies: List[BaseStrategy] = [FrequencyStrategy(), ColdNumberStrategy(), MarkovStrategy()]
    if use_ml:
        strategies.append(MLStrategy())
    return strategies


def full_report(digits: List[int], symbol: str, use_ml: bool = True) -> Dict:
    freq = stats_mod.digit_frequency(digits)
    chi2, chi_p = stats_mod.chi_square_uniformity(digits)
    autocorr = stats_mod.autocorrelation(digits)
    trans = stats_mod.transition_matrix(digits)

    runs_results = {}
    for d in range(10):
        binary = [1 if x == d else 0 for x in digits]
        z, p = stats_mod.runs_test(binary)
        runs_results[d] = {"z": z, "p_value": p, "significant": p < 0.05}

    # Separate strategy instances for Matches vs. Differs scoring so their
    # internal state doesn't get shared/contaminated between the two runs.
    match_strategies = build_strategies(use_ml=use_ml)
    backtests_matches = [backtest_exact_match(s, digits) for s in match_strategies]

    differ_strategies = build_strategies(use_ml=use_ml)
    backtests_differs = [backtest_differs(s, digits) for s in differ_strategies]

    # match_strategies have now each ingested the full history via
    # update() during backtesting, so calling .predict() again gives an
    # honest "next digit" forecast rather than requiring a third pass.
    live_recommendations = []
    for strat, result in zip(match_strategies, backtests_matches):
        live_recommendations.append({
            "strategy": strat.name,
            "suggested_digit": strat.predict(),
            "backtested_accuracy": result.accuracy,
            "significant_edge": result.significant,
        })

    return {
        "symbol": symbol,
        "sample_size": len(digits),
        "digit_frequency_pct": freq,
        "chi_square": {"statistic": chi2, "p_value": chi_p, "uniform_at_5pct": chi_p >= 0.05},
        "autocorrelation_lag1_10": autocorr,
        "runs_test_per_digit": runs_results,
        "transition_matrix": trans.tolist(),
        "backtests_matches": backtests_matches,
        "backtests_differs": backtests_differs,
        "live_recommendations": live_recommendations,
    }
