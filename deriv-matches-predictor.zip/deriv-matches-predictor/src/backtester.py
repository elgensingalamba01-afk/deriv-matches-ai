"""
Walk-forward backtesting for digit-prediction strategies.

At each step, a strategy only sees digits that occurred before the one
it's trying to predict — no look-ahead, exactly like a live bot would
have to operate. Results are compared to the true baseline rate with a
binomial significance test, not just reported as raw accuracy, so a
strategy has to clear an actual statistical bar before being called
anything other than noise.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List

from scipy import stats

from .strategies import BaseStrategy


@dataclass
class BacktestResult:
    strategy_name: str
    n_predictions: int
    n_correct: int
    accuracy: float
    baseline: float
    p_value: float
    significant: bool


def _binomial_result(strategy_name: str, correct: int, total: int, baseline: float) -> BacktestResult:
    accuracy = correct / total if total else 0.0
    if total:
        p_value = float(stats.binomtest(correct, total, baseline, alternative="two-sided").pvalue)
    else:
        p_value = 1.0
    return BacktestResult(
        strategy_name=strategy_name,
        n_predictions=total,
        n_correct=correct,
        accuracy=accuracy,
        baseline=baseline,
        p_value=p_value,
        significant=p_value < 0.05,
    )


def backtest_exact_match(strategy: BaseStrategy, digits: List[int], min_history: int = 30) -> BacktestResult:
    """Scores a strategy on 'Matches' (exact digit hit). Baseline for a
    random guess is 1/10 = 10%."""
    correct = 0
    total = 0
    for i, actual in enumerate(digits):
        if i >= min_history:
            if strategy.predict() == actual:
                correct += 1
            total += 1
        strategy.update(actual)
    return _binomial_result(strategy.name, correct, total, baseline=0.10)


def backtest_differs(strategy: BaseStrategy, digits: List[int], min_history: int = 30) -> BacktestResult:
    """Scores a strategy on 'Differs' (predicted digit is correct to
    AVOID). Baseline for a random guess is 9/10 = 90%."""
    correct = 0
    total = 0
    for i, actual in enumerate(digits):
        if i >= min_history:
            if strategy.predict() != actual:
                correct += 1
            total += 1
        strategy.update(actual)
    return _binomial_result(strategy.name, correct, total, baseline=0.90)
